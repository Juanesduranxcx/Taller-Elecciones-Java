package com.taller4.models;

public class Candidato {
    private int id;
    private int puntosAgregados ;
    public Candidato(int id ){
        this.id = id;
        this.puntosAgregados = 0;
    }
    public void añadirPuntos(int cantidad){

        this.puntosAgregados += cantidad;

    }

    public int getPuntosAgregados() {
        return this.puntosAgregados;
    }
    public int getId() {
        return id;
    }
}
