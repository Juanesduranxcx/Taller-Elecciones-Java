package com.taller4.models;

import java.util.ArrayList;
import java.util.List;

public class ResultadoEleccion {
    String metodo;
    int totalVoto;
    int valido;
    int nulo;
    List<Candidato> resultado = new ArrayList<>();
    List<Integer> ganador ;

    public ResultadoEleccion(String metodo, int totalVoto, int valido, int nulo, List<Candidato> resultado, List<Integer> ganador){
        this.metodo = metodo;
        this.totalVoto = totalVoto;
        this.valido = valido;
        this.nulo = nulo ;
        this.resultado = resultado;
        this.ganador = ganador;

    }
    public String getmetodo(){
        return metodo;
    }
    public int getTotalVoto(){
        return totalVoto;
    }
    public int getValido(){
        return valido;
    }
    public int getNulo() {
        return nulo;
    }
    public List<Candidato> getResultado(){
        return resultado;
    }

    public List<Integer> getGanador() {
        return ganador;
    }
}
